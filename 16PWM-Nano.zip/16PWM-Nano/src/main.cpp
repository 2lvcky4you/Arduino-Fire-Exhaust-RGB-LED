#include <Arduino.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pwm1 = Adafruit_PWMServoDriver(0x40);

int steer = 0;
int throttle = 0;

void setup() {
  Serial.begin(9600);

  pwm1.begin();
  pwm1.setOscillatorFrequency(27000000);
  pwm1.setPWMFreq(300);

  pinMode(3, INPUT);
  pinMode(5, INPUT);

}

void loop() {

  if(steer <= 1300)
  {
    pwm1.setPWM(0,1,1600);
    pwm1.setPWM(1,1,1);
    pwm1.setPWM(2,1,1);
  
    pwm1.setPWM(3,1,1600);
    pwm1.setPWM(4,1,1);
    pwm1.setPWM(5,1,1);
  
    pwm1.setPWM(6,1,1600);
    pwm1.setPWM(7,1,1600);
    pwm1.setPWM(8,1,1600);
  
    pwm1.setPWM(9,1,1600);
    pwm1.setPWM(10,1,1600);
    pwm1.setPWM(11,1,1600);

    delay(300);

    pwm1.setPWM(0,1,1600);
    pwm1.setPWM(1,1,1);
    pwm1.setPWM(2,1,1);
  
    pwm1.setPWM(3,1,1600);
    pwm1.setPWM(4,1,400);
    pwm1.setPWM(5,1,1);
  
    pwm1.setPWM(6,1,1600);
    pwm1.setPWM(7,1,1600);
    pwm1.setPWM(8,1,1);
  
    pwm1.setPWM(9,1,1600);
    pwm1.setPWM(10,1,1600);
    pwm1.setPWM(11,1,1600);

    delay(300);

  }
  else if (steer >= 1700)
  {
    pwm1.setPWM(0,1,1600);
    pwm1.setPWM(1,1,1);
    pwm1.setPWM(2,1,1);
  
    pwm1.setPWM(3,1,1600);
    pwm1.setPWM(4,1,1);
    pwm1.setPWM(5,1,1);
  
    pwm1.setPWM(6,1,1600);
    pwm1.setPWM(7,1,1600);
    pwm1.setPWM(8,1,1600);
  
    pwm1.setPWM(9,1,1600);
    pwm1.setPWM(10,1,1600);
    pwm1.setPWM(11,1,1600);

    delay(300);

    pwm1.setPWM(0,1,1600);
    pwm1.setPWM(1,1,400);
    pwm1.setPWM(2,1,1);
  
    pwm1.setPWM(3,1,1600);
    pwm1.setPWM(4,1,1);
    pwm1.setPWM(5,1,1);
  
    pwm1.setPWM(6,1,1600);
    pwm1.setPWM(7,1,1600);
    pwm1.setPWM(8,1,1600);
  
    pwm1.setPWM(9,1,1600);
    pwm1.setPWM(10,1,1600);
    pwm1.setPWM(11,1,1);

    delay(300);
  }
  else
  {
    pwm1.setPWM(0,1,1600);
    pwm1.setPWM(1,1,1);
    pwm1.setPWM(2,1,1);
  
    pwm1.setPWM(3,1,1600);
    pwm1.setPWM(4,1,1);
    pwm1.setPWM(5,1,1);
  
    pwm1.setPWM(6,1,1600);
    pwm1.setPWM(7,1,1600);
    pwm1.setPWM(8,1,1600);
  
    pwm1.setPWM(9,1,1600);
    pwm1.setPWM(10,1,1600);
    pwm1.setPWM(11,1,1600);
  }



  delay(10);

  steer = pulseIn(3, HIGH);
  throttle = pulseIn(5, HIGH);
  Serial.println(throttle);
}